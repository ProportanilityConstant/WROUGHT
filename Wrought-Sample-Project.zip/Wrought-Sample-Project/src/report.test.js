import { buildReport } from './report.js';

const report = buildReport([{ label: 'Example', values: [2, 3, 5] }]);
console.assert(report[0].total === 10, 'Report total should be 10');
