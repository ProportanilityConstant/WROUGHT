export function buildReport(items) {
  return items.map((item) => ({
    label: item.label,
    total: item.values.reduce((sum, value) => sum + value, 0)
  }));
}
