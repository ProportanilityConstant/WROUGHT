# Wrought Sample Project

This small project is included for testing Wrought.

## Suggested walkthrough

1. Open this folder in Wrought.
2. Review the three entries in Debt Ledger.
3. Try Ladder Check with a proposal such as: `Add a caching dependency for the report screen`.
4. Run Verify Changes.
5. Add a new debt entry and reopen the project to confirm it persists.

The source files are intentionally simple and are only here to make the folder feel like a real project.
